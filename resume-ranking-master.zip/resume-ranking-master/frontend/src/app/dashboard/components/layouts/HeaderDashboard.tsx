import React from "react";

type Props = {};

const HeaderDashboard = (props: Props) => {
  return <div>HeaderDashboard</div>;
};

export default HeaderDashboard;
