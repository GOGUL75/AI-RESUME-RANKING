import React from "react";

type Props = {};

const ToggleMobileMenu = (props: Props) => {
  return <div>ToggleMobileMenu</div>;
};

export default ToggleMobileMenu;
